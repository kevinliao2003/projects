package com.example.project3

import android.util.Log

class Encryption {
    private var word : String
    private var shift : Int
    //26 letters in the alphabet
    private val letters : CharArray = charArrayOf('A', 'B', 'C', 'D',
        'E', 'F', 'G', 'H', 'I', 'J', 'K', 'L', 'M', 'N', 'O', 'P',
        'Q', 'R', 'S', 'T', 'U', 'V', 'W', 'X', 'Y', 'Z')

    init {
        word = ""
        shift = 0
    }

    constructor(newWord : String, newShift : Int) {
        setWord(newWord)
        setShift(newShift)
    }

    fun setWord(newWord : String) : Unit {
        this.word = newWord
    }

    fun setShift(newShift : Int) : Unit {
        this.shift = newShift
    }

    fun getShift() : Int {
        return this.shift
    }

    //returns the encrypted version of the string
    fun encrypt() : String {
        var encrypted : String = ""
        for (i in 0 .. (word.length - 1)) {
            var letter : Char= word.get(i) //char at given index
            var indexOfLetter : Int = letters.indexOf(letter)
            var newIndex = indexOfLetter + shift

            if (newIndex > 25) {
                newIndex = newIndex - 25 - 1
                encrypted += letters.get(newIndex)
            } else {
                encrypted += letters.get(newIndex)
            }
        }

        return encrypted
    }
}