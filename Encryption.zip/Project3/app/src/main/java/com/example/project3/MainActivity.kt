package com.example.project3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView

//Names: Kevin Liao, Elan Fisher
class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
    }

    fun modifyData(v : View) {
        //run
        var shift : Int = run(v)
        if (run(v) != -1) { //if the shift is in range
            //goes to EncryptActivity
            encrypt = Encryption("", 0)
            encrypt.setShift(shift)
            var myIntent : Intent = Intent(this, EncryptActivity::class.java)
            startActivity(myIntent)
        }
    }

    fun run(V : View) : Int {
        var numberET : EditText = findViewById(R.id.text_number)
        var warningTV : TextView = findViewById(R.id.text_warning)
        var numberAmount : Int = 0

        try {
            numberAmount = Integer.parseInt(numberET.getText().toString())
            //if the user enters an integer outside the range
            if (numberAmount < 1 || numberAmount > 25) {
                //tells the user to enter integers between 1 and 25
                warningTV.setText("Please enter a number between 0 and 25")
                return -1
            } else {
                warningTV.setText("")
            }
        } catch (nfe : java.lang.NumberFormatException) {
            warningTV.setText("Please enter a number between 0 and 25")
        }

        return numberAmount
    }

    companion object {
        lateinit var encrypt : Encryption
    }
}