package com.example.project3

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.view.View
import android.widget.EditText
import android.widget.TextView

class EncryptActivity : AppCompatActivity() {
    var encrypt_object : Encryption = MainActivity.encrypt

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //setContentView(R.layout.activity_main)
        setContentView(R.layout.activity_encrypt)

        var shiftTV : TextView = findViewById(R.id.label_shift)
        shiftTV.setText("Shift = " + encrypt_object.getShift())
    }

    fun encrypt(v : View) {
        var wordET : EditText = findViewById(R.id.word_hint)
        var wordString : String = wordET.text.toString()
        var resultTV : TextView = findViewById(R.id.label_result_encryption)

        encrypt_object.setWord(wordString) //sets string to encrypt
        var encrypted : String = encrypt_object.encrypt()

        resultTV.setText(encrypted)
    }

    fun goBack(v : View) {
        //goes back
        finish()
    }
}